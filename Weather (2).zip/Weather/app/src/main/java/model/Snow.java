package model;

public class Snow {
    private int percipitation;

    public int getPercipitation() {
        return percipitation;
    }

    public void setPercipitation(int percipitation) {
        this.percipitation = percipitation;
    }
}
