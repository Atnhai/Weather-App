package model;

public class Clouds {
    private int precipitation;

    public int precipitation() {
        return precipitation;
    }

    public void setPrecipitation(int precipitation){
        this.precipitation = precipitation;
    }
}
